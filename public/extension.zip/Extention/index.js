/**
 * index.js - Vanilla JS Implementation
 * Optimized for Manifest V3 CSP compliance.
 */

function renderApp() {
  const container = document.getElementById('root');
  if (!container) return;

  container.innerHTML = `
    <div style="font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #3c4043; width: 320px; background: #ffffff; display: flex; flex-direction: column; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
      <div style="background: linear-gradient(135deg, #1a73e8 0%, #1557b0 100%); padding: 24px 20px; color: white; text-align: center;">
        <div style="font-size: 2.5rem; margin-bottom: 8px;">🛡️</div>
        <h1 style="margin: 0; font-size: 1.25rem; font-weight: 700; letter-spacing: 0.5px;">Before You Send</h1>
        <p style="margin: 4px 0 0; opacity: 0.9; font-size: 0.85rem;">Professional Integrity v2.6.3</p>
      </div>
      
      <div style="padding: 20px;">
        <div style="background: #f8f9fa; border-radius: 12px; padding: 16px; border: 1px solid #e8eaed; margin-bottom: 20px;">
          <div style="display: flex; align-items: center; margin-bottom: 10px;">
            <div style="width: 10px; height: 10px; border-radius: 50%; background: #1e8e3e; margin-right: 10px; box-shadow: 0 0 5px rgba(30, 142, 62, 0.5);"></div>
            <span style="font-size: 0.85rem; font-weight: 600; color: #202124;">System Active</span>
          </div>
          <div style="font-size: 0.8rem; color: #5f6368; line-height: 1.4;">
            BYS is currently protecting your signatures and tables while auditing for tone and professional clarity.
          </div>
        </div>

        <div style="text-align: center; font-size: 0.85rem; color: #70757a; margin-top: 24px; padding-top: 16px; border-top: 1px solid #eee;">
          Built with excellence by <a href="https://www.linkedin.com/in/yadavritik" target="_blank" rel="noopener noreferrer" style="color: #1a73e8; text-decoration: none; font-weight: 700;">Ritik</a>
        </div>
      </div>
    </div>
  `;
}

// Ensure DOM is ready without module overhead
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', renderApp);
} else {
  renderApp();
}