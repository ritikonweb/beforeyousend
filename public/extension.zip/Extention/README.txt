
"Before You Send" Alignment Instructions
----------------------------------------

STEP 1: VERCEL DEPLOYMENT
1. Create a new project in Vercel.
2. Upload the contents of the 'vercel/' folder.
3. In Vercel Project Settings -> Environment Variables, add:
   GOOGLE_AI_API_KEY = (Your Gemini API Key)
4. Deploy the project.
5. Copy your deployment URL (e.g., https://my-app.vercel.app).

STEP 2: EXTENSION ALIGNMENT
1. Open 'background.js'.
2. Ensure the 'API_URL' variable matches your deployment URL + '/api/review-email'.
3. Open 'manifest.json' and ensure your URL is in 'host_permissions'.

STEP 3: LOAD EXTENSION
1. Go to chrome://extensions
2. Enable Developer Mode.
3. Load Unpacked -> select your extension folder.

FIX FOR "ear" vs "Dear":
The backend route.js now includes a "Contextual Typo" rule in the system prompt and uses the latest 'gemini-3-flash-preview' model, which is far more effective at catching greetings and grammar errors in context.
