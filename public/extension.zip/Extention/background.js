/**
 * background.js
 * Network handler with intelligent error classification.
 */

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'REVIEW_EMAIL') {
    const { subject, body, mode } = request.payload;
    const API_URL = "https://beforeusend.vercel.app/api/review-email";

    fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ subject, body, mode })
    })
    .then(async response => {
      if (!response.ok) {
        const errorText = await response.text();
        // Pack status into the error message for detection
        throw new Error(`STATUS:${response.status}|${errorText || 'Unknown'}`);
      }
      return response.json();
    })
    .then(data => {
      sendResponse({ ok: true, data });
    })
    .catch(error => {
      const msg = error.message || "";
      
      // If it is a quota limit (429), log as a warning ONLY.
      // Warnings do not trigger the red error badge in Chrome Extensions.
      if (msg.includes("429") || msg.toLowerCase().includes("limit") || msg.toLowerCase().includes("exhausted")) {
        console.warn("BYS API Notice (Quota):", msg);
        sendResponse({ ok: false, error: "LIMIT_EXHAUSTED" });
      } else {
        console.error("BYS System Error:", error);
        sendResponse({ ok: false, error: msg });
      }
    });

    return true; 
  }
});