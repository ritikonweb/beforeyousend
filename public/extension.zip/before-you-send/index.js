/**
 * index.js - Ultra-Refined BYS Dashboard
 * Optimized for compact dimensions and professional precision.
 */

function renderApp() {
  const container = document.getElementById('root');
  if (!container) return;

  container.innerHTML = `
    <div style="display: flex; flex-direction: column; height: 100vh; background: #ffffff; position: relative; overflow: hidden; box-sizing: border-box;">
      
      <!-- Premium Gradient Header -->
      <div style="height: 100px; background: linear-gradient(180deg, #1a73e8 0%, #1557b0 100%); position: relative; width: 100%; flex-shrink: 0;">
        <!-- Refined Abstract Decorative Shapes -->
        <div style="position: absolute; top: -15px; right: -15px; width: 90px; height: 90px; background: rgba(255,255,255,0.07); border-radius: 35%; transform: rotate(-15deg);"></div>
        <div style="position: absolute; bottom: 10px; left: 15px; width: 45px; height: 45px; background: rgba(255,255,255,0.04); border-radius: 25%; transform: rotate(15deg);"></div>
      </div>

      <!-- High-Fidelity Shield Icon (Overlapping) -->
      <div style="position: absolute; top: 68px; left: 50%; transform: translateX(-50%); z-index: 100;">
        <div style="width: 64px; height: 64px; background: #1a73e8; border-radius: 16px; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 12px rgba(0,0,0,0.18); border: 4px solid #fff;">
          <div style="font-size: 2.2rem; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.1));">🛡️</div>
        </div>
      </div>

      <!-- Content Section -->
      <div style="flex: 1; padding: 0 18px 16px; display: flex; flex-direction: column; position: relative; z-index: 10; margin-top: -15px;">
        
        <!-- Status Card -->
        <div style="background: #ffffff; border-radius: 20px; padding: 42px 20px 20px; border: 1px solid #f1f3f4; box-shadow: 0 6px 20px rgba(0,0,0,0.05); margin-top: 25px;">
          <div style="display: flex; align-items: center; margin-bottom: 10px;">
            <!-- Subtle Pulsing Status Indicator -->
            <div style="position: relative; width: 10px; height: 10px; margin-right: 12px; flex-shrink: 0;">
                <div style="width: 10px; height: 10px; border-radius: 50%; background: #34a853;"></div>
                <div style="position: absolute; top: 0; left: 0; width: 10px; height: 10px; border-radius: 50%; background: #34a853; animation: pulse 2.5s infinite;"></div>
            </div>
            <span style="font-size: 0.95rem; font-weight: 700; color: #202124; letter-spacing: -0.1px;">Active Protection</span>
          </div>
          <p style="font-size: 0.85rem; color: #5f6368; line-height: 1.5; margin: 0; font-weight: 400;">
            BYS is currently monitoring your Gmail drafts. It automatically intercepts send actions to ensure professional integrity.
          </p>
        </div>

        <!-- Features Grid -->
        <div style="margin-top: 24px; display: flex; flex-direction: column; gap: 16px; padding-left: 6px;">
          <div style="display: flex; align-items: center; gap: 12px;">
            <div style="font-size: 1.2rem; min-width: 20px; text-align: center;">✨</div>
            <div style="font-size: 0.88rem; color: #3c4043; font-weight: 500;">Contextual Typo Detection Active</div>
          </div>
          <div style="display: flex; align-items: center; gap: 12px;">
            <div style="font-size: 1.2rem; min-width: 20px; text-align: center;">📊</div>
            <div style="font-size: 0.88rem; color: #3c4043; font-weight: 500;">Tone Analysis Engine Ready</div>
          </div>
          <div style="display: flex; align-items: center; gap: 12px;">
            <div style="font-size: 1.2rem; min-width: 20px; text-align: center;">🔒</div>
            <div style="font-size: 0.88rem; color: #3c4043; font-weight: 500;">Formatting Integrity Locked</div>
          </div>
        </div>

        <div style="flex: 1;"></div>

        <!-- Clean Compact Footer -->
        <div style="text-align: center; border-top: 1px solid #f8f9fa; padding-top: 16px; margin-bottom: 4px;">
          <p style="font-size: 0.75rem; color: #9aa0a6; margin: 0 0 4px; font-weight: 500;">Built for modern professionals</p>
          <a href="https://www.linkedin.com/in/yadavritik" target="_blank" rel="noopener noreferrer" style="color: #1a73e8; text-decoration: none; font-size: 0.88rem; font-weight: 700; transition: color 0.2s ease;">
            Created by Ritik
          </a>
        </div>
      </div>
    </div>

    <style>
      @keyframes pulse {
        0% { transform: scale(1); opacity: 0.7; }
        70% { transform: scale(2.5); opacity: 0; }
        100% { transform: scale(1); opacity: 0; }
      }
      * {
        box-sizing: border-box;
        -webkit-font-smoothing: antialiased;
      }
      body {
        margin: 0;
        background: #ffffff;
        user-select: none;
      }
      a:hover {
        color: #1557b0 !important;
      }
    </style>
  `;
}

// Global initialization
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', renderApp);
} else {
  renderApp();
}
