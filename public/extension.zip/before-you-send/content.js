
/**
 * Before You Send - Content Script v2.6.1
 * Deep Structural Integrity & Content Memoization
 * Enhanced Error Handling for Quota Limits
 */

let isBypassing = false;
let currentModal = null;
let lastApprovedText = ""; 
let lastApprovedSubject = "";
let savedTableHTML = ""; 
let savedSignatureHTML = "";

const GMAIL_SEND_SELECTORS = [
  'div[role="button"][data-tooltip*="Send"]',
  '.aoO',
  '.T-I.J-J5-Ji.aoO'
];

function findComposeContainer(sendButton) {
  return sendButton.closest('div.M9, div.adP, div.inbox-sdk-compose, .dw');
}

/**
 * Specifically finds and snapshots tables and signatures as HTML blocks.
 */
function snapshotStructures(bodyEl) {
  savedTableHTML = "";
  savedSignatureHTML = "";

  // 1. Capture Table
  const table = bodyEl.querySelector('table');
  if (table) {
    savedTableHTML = table.outerHTML;
  }

  // 2. Capture Signature
  const sig = bodyEl.querySelector('.gmail_signature') || 
              bodyEl.querySelector('div[signature]') || 
              bodyEl.querySelector('.gmail_extra');
  
  if (sig) {
    savedSignatureHTML = sig.outerHTML;
  } else {
    const html = bodyEl.innerHTML;
    const sigIndex = html.search(/--\s?<br>|Best Regards|Thanks,|Regards,/i);
    if (sigIndex !== -1) {
      savedSignatureHTML = html.substring(sigIndex);
    }
  }
}

function getEmailContent(sendButton) {
  const container = findComposeContainer(sendButton);
  if (!container) return { subject: '', body: '' };
  
  const subjEl = container.querySelector('input[name="subjectbox"]') || container.querySelector('input[aria-label="Subject"]');
  const bodyEl = container.querySelector('div[role="textbox"][aria-label="Message Body"]');
  
  const fullText = bodyEl ? bodyEl.innerText : '';
  const currentSubject = subjEl ? subjEl.value : '';

  if (bodyEl) snapshotStructures(bodyEl);

  return {
    subject: currentSubject,
    body: fullText.trim()
  };
}

function updateGmailDraft(sendButton, newBodyText) {
  const container = findComposeContainer(sendButton);
  if (!container) return;
  const bodyEl = container.querySelector('div[role="textbox"][aria-label="Message Body"]');
  const subjEl = container.querySelector('input[name="subjectbox"]') || container.querySelector('input[aria-label="Subject"]');

  if (bodyEl) {
    let cleanText = newBodyText;
    const sigStarts = [/Best Regards/i, /Thanks,/i, /Regards,/i, /--/];
    for (const pattern of sigStarts) {
      const index = cleanText.search(pattern);
      if (index !== -1) {
        cleanText = cleanText.substring(0, index).trim();
        break;
      }
    }

    let finalHTML = `<div>${cleanText.replace(/\n/g, '<br>')}</div>`;
    if (savedTableHTML) finalHTML += `<br>${savedTableHTML}`;
    if (savedSignatureHTML) finalHTML += `<br>${savedSignatureHTML}`;

    bodyEl.innerHTML = finalHTML;
    lastApprovedText = bodyEl.innerText.trim();
    lastApprovedSubject = subjEl ? subjEl.value : '';
    
    ['input', 'change', 'blur'].forEach(evt => bodyEl.dispatchEvent(new Event(evt, { bubbles: true })));
  }
}

function showModal(sendButton) {
  if (currentModal) return;

  const overlay = document.createElement('div');
  overlay.id = 'bys-modal-overlay';
  overlay.innerHTML = `
    <div id="bys-modal-container">
      <div class="bys-header">
        <div style="display: flex; align-items: center; gap: 12px;">
          <span style="font-size: 1.8rem;">🛡️</span>
          <div>
            <h2 style="margin:0; color:#1a73e8; font-size:1.2rem;">Before You Send</h2>
            <p id="bys-status" style="margin:2px 0 0; color:#5f6368; font-size:0.8rem;">Structural Integrity Locked...</p>
          </div>
        </div>
      </div>
      <div class="bys-body">
        <div id="bys-view-loading">
          <div class="bys-spinner"></div>
          <p class="bys-hint">Protecting your original table and signature formatting...</p>
        </div>
        <div id="bys-view-exhausted" style="display: none; text-align: center; padding: 40px 20px;">
          <div style="font-size: 3rem; margin-bottom: 20px;">⏳</div>
          <h3 style="color: #3c4043; margin-bottom: 12px;">Daily Limit Reached</h3>
          <p style="color: #5f6368; line-height: 1.6; max-width: 400px; margin: 0 auto 24px;">
            You've reached your daily professional audit limit. Please try again tomorrow to continue sending with total confidence.
          </p>
          <p style="font-size: 0.8rem; color: #9aa0a6;">Your draft remains safe and unchanged.</p>
        </div>
        <div id="bys-view-results" style="display: none;">
          <div id="bys-score-tag" class="bys-score-tag">Tone: <span id="bys-tone-val">--</span></div>
          <div class="bys-label">Audit Results:</div>
          <div id="bys-grammar-box" class="bys-issue-row"></div>
          <div class="bys-label">Tone Feedback:</div>
          <div id="bys-tone-box" class="bys-issue-row"></div>
          <div class="bys-label">Proposed Draft (Editable):</div>
          <textarea id="bys-suggested-box" class="bys-editable-area" spellcheck="false"></textarea>
          <p class="bys-tiny-hint">Tables and signatures will be restored with original formatting on Apply.</p>
        </div>
      </div>
      <div class="bys-footer">
        <div id="bys-actions-results" class="bys-btn-group" style="display: none;">
          <button id="bys-btn-anyway" class="bys-btn bys-btn-warning">Send Anyway</button>
          <button id="bys-btn-cancel" class="bys-btn bys-btn-secondary">Cancel</button>
          <div style="flex: 1; text-align: center;">
             <button id="bys-btn-retry" class="bys-btn bys-btn-retry">Regenerate</button>
          </div>
          <button id="bys-btn-apply" class="bys-btn bys-btn-primary">Apply Changes</button>
          <button id="bys-btn-apply-send" class="bys-btn bys-btn-success">Apply & Send</button>
        </div>
        <div id="bys-actions-exhausted" class="bys-btn-group" style="display: none;">
          <button id="bys-btn-anyway-ex" class="bys-btn bys-btn-warning">Send Anyway</button>
          <div style="flex: 1;"></div>
          <button id="bys-btn-cancel-ex" class="bys-btn bys-btn-secondary">Dismiss</button>
        </div>
        <div class="bys-credits-modal">Built with excellence by <a href="https://www.linkedin.com/in/yadavritik" target="_blank">Ritik</a></div>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  currentModal = overlay;
  
  callBackend(sendButton);
}

function callBackend(sendButton) {
  const payload = getEmailContent(sendButton);
  
  const loading = document.getElementById('bys-view-loading');
  const exhausted = document.getElementById('bys-view-exhausted');
  const results = document.getElementById('bys-view-results');
  const actionsRes = document.getElementById('bys-actions-results');
  const actionsExh = document.getElementById('bys-actions-exhausted');

  loading.style.display = 'block';
  exhausted.style.display = 'none';
  results.style.display = 'none';
  actionsRes.style.display = 'none';
  actionsExh.style.display = 'none';

  chrome.runtime.sendMessage({ action: 'REVIEW_EMAIL', payload }, (response) => {
    if (response && response.ok) {
      displayResults(response.data, sendButton);
    } else {
      const errorMsg = response.error || "";
      if (errorMsg.includes("LIMIT_EXHAUSTED") || errorMsg.includes("429")) {
        loading.style.display = 'none';
        exhausted.style.display = 'block';
        actionsExh.style.display = 'flex';
        document.getElementById('bys-status').innerText = "Limit Reached";
        
        document.getElementById('bys-btn-cancel-ex').onclick = closeModal;
        document.getElementById('bys-btn-anyway-ex').onclick = () => {
          isBypassing = true;
          sendButton.click();
          closeModal();
        };
      } else {
        document.getElementById('bys-status').innerText = "System Interruption";
        loading.innerHTML = `
          <div style="padding: 40px;">
            <p style="color:#d93025; font-weight: 700;">Audit Interrupted</p>
            <p style="color:#5f6368; font-size:0.9rem;">${response.error || 'Failed to reach auditor. Please check your connection.'}</p>
          </div>
        `;
        actionsRes.style.display = 'flex';
        // Hide primary actions on hard error
        document.getElementById('bys-btn-apply').style.display = 'none';
        document.getElementById('bys-btn-apply-send').style.display = 'none';
        showResultButtons(sendButton);
      }
    }
  });
}

function displayResults(data, sendButton) {
  const loading = document.getElementById('bys-view-loading');
  const results = document.getElementById('bys-view-results');
  const actions = document.getElementById('bys-actions-results');

  if (loading) loading.style.display = 'none';
  if (results) results.style.display = 'block';
  if (actions) actions.style.display = 'flex';
  document.getElementById('bys-status').innerText = "Structural Audit Complete";

  const { issues_detected, tone_score, suggested_body } = data;
  document.getElementById('bys-tone-val').innerText = tone_score || 'Professional';
  document.getElementById('bys-grammar-box').innerText = issues_detected.grammar_spelling || "No formatting issues detected.";
  document.getElementById('bys-tone-box').innerText = issues_detected.tone || "Tone is appropriate.";
  
  let cleanedBody = suggested_body;
  const sigStarts = [/Best Regards/i, /Thanks,/i, /Regards,/i, /--/];
  for (const pattern of sigStarts) {
    const index = cleanedBody.search(pattern);
    if (index !== -1) {
      cleanedBody = cleanedBody.substring(0, index).trim();
      break;
    }
  }

  document.getElementById('bys-suggested-box').value = cleanedBody;
  showResultButtons(sendButton);
}

function showResultButtons(sendButton) {
  document.getElementById('bys-btn-cancel').onclick = closeModal;
  document.getElementById('bys-btn-retry').onclick = () => {
    lastApprovedText = ""; 
    callBackend(sendButton);
  };

  document.getElementById('bys-btn-anyway').onclick = () => {
    isBypassing = true;
    sendButton.click();
    closeModal();
  };

  const applyBtn = document.getElementById('bys-btn-apply');
  if (applyBtn) {
    applyBtn.onclick = () => {
      updateGmailDraft(sendButton, document.getElementById('bys-suggested-box').value);
      closeModal();
    };
  }

  const applySendBtn = document.getElementById('bys-btn-apply-send');
  if (applySendBtn) {
    applySendBtn.onclick = () => {
      updateGmailDraft(sendButton, document.getElementById('bys-suggested-box').value);
      isBypassing = true;
      setTimeout(() => { sendButton.click(); closeModal(); }, 200);
    };
  }
}

function closeModal() {
  if (currentModal) { currentModal.remove(); currentModal = null; }
}

function init() {
  const observer = new MutationObserver(() => {
    const btns = document.querySelectorAll(GMAIL_SEND_SELECTORS.join(','));
    btns.forEach(btn => {
      if (btn.dataset.bysMark === 'true') return;
      btn.addEventListener('click', (e) => {
        if (isBypassing) { isBypassing = false; return; }

        const currentContent = getEmailContent(btn);
        
        if (lastApprovedText && currentContent.body === lastApprovedText && currentContent.subject === lastApprovedSubject) {
          return; 
        }

        e.preventDefault();
        e.stopImmediatePropagation();
        showModal(btn);
      }, true);
      btn.dataset.bysMark = 'true';
    });
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

init();
